<?php

use \LaravelTranslate\Languages as Languages;


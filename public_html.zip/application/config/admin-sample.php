<?php return array (
  'username' => 'admin',
  'password' => 'admin',
);
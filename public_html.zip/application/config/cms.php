<?php

return [
   "contentDirectory"  => 'content',
    "applicationDirectory" => 'application'
];
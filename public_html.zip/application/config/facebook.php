<?php
// app/config/facebook.php

// Facebook app Config 
return array(
		//AppId and secret set in dashboard
        /*'appId' => '',
        'secret' => '',*/
		'defaultScope' => 'email'
    );
<?php

return [
    'public_path'  =>  'content/plugins',
    'asset_method' => 'content_url'
];
<?php

return $sharingNetworkNames = [
    'facebook'      =>  'Facebook',
    'twitter'       =>  'Twitter',
    'googleplus'    =>  'Google plus',
    'pinterest'     =>  'Pinterest',
    'tumblr'        =>  'Tumblr',
    'reddit'        =>  'Reddit',
    'vk'            =>  'VK',
    'ok'            =>  'OK.ru'
];
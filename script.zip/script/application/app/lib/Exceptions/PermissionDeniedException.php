<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 03/04/15
 * Time: 8:00 PM
 */

class PermissionDeniedException extends Exception{

}
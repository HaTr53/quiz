<?php
namespace ResultGenerator\Exceptions;
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 20/03/17
 * Time: 5:43 PM
 */
class ResultGeneratorException extends \Exception
{

}
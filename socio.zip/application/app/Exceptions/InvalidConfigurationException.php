<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 07/01/16
 * Time: 1:45 AM
 */

namespace App\Exceptions;


class InvalidConfigurationException extends \Exception{

}
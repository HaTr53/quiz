<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 10/11/15
 * Time: 4:53 PM
 */

namespace Jitheshgopan\LaravelPlugins\Exceptions;


class PluginNotInstalledException extends \Exception{

}